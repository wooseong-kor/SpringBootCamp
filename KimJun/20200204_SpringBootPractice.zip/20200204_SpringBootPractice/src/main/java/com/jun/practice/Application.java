package com.jun.practice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

	//main메소드를 가지는 Class, 단순히 main 메소드를 실행하는 기능만 가질 뿐이다.
@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}
	
}	
