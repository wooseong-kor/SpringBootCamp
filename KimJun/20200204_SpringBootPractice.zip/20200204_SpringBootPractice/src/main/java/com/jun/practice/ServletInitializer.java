package com.jun.practice;

import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

	// 프로젝트 생성 시 Packages를 war로 선택하면 나타나는 Class
	// 서블릿을 실행하는 역할을 수행
public class ServletInitializer extends SpringBootServletInitializer {

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(Application.class);
	}

}	// 
