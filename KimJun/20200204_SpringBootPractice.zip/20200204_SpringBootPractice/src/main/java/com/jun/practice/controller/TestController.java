package com.jun.practice.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jun.practice.dto.TestDto;

	// xml에서 component-scan과 같은 별도의 설정 작업 없이 어노테이션을 적용하면 bean으로 자동등록된다.
	// 이를 위해 패키지명을 통일할 필요가 있으며 그렇지 못할 경우 @ComponentScan이라는 어노테이션을 통해 빈으로 등록할 수 있다.
	// ex) ComponentScan(basePackages={"com.jun.test", "com.jun.test2"})
@RestController
public class TestController {

	@GetMapping("/hello")
	public String sayHello() {
		
		return "Hello World";
	}
	
	@GetMapping("/sample")
	public TestDto Human() {
		
		TestDto dto = new TestDto();
		dto.setName("김준");
		dto.setAge("29");
		dto.setSex("male");
		
		System.out.println(dto);
		
		return dto;
	}
}
