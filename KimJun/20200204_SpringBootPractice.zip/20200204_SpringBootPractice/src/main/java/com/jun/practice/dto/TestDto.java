package com.jun.practice.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString			// @Data라는 어노테이션으로 getter/setter/ToString/Constructor를 모두 설정할 수 있다.
public class TestDto {

	private String name;
	private String age;
	private String sex;
}
