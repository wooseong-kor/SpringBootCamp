package com.jun.kim.controller;

import java.util.List;

import org.mybatis.spring.annotation.MapperScan;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.jun.kim.dto.Board_Dto;
import com.jun.kim.mapper.TestMapper;



@Controller
@MapperScan("com.jun.kim.mapper")
public class MainController {

	Logger log = LoggerFactory.getLogger(MainController.class);
	@Autowired
	TestMapper mapper;
	
	@GetMapping("/")
	public String main() {
		log.info("maintest");
		return "main";
	}
	
	@GetMapping("/move")
	public String move() {
		return "move";
	}
	
	@RequestMapping(value="/all", method = {RequestMethod.GET, RequestMethod.POST})
	public String selectAll(Model model) {
		log.info("전체조회");
		List<Board_Dto> lists = mapper.selectAll();
		model.addAttribute("lists", lists);
		return "selectAll";
	}
	
	@RequestMapping(value="/one", method = {RequestMethod.GET, RequestMethod.POST})
	public String selectOne(Model model, int board_seq) {
		log.info("상세조회, {}", board_seq);
		Board_Dto dto = mapper.selectOne(board_seq);
		model.addAttribute("dto", dto);
		return "selectOne";
	}
	
	
	
	
	
	
}
