package com.jun.kim.dto;

import java.io.Serializable;

import lombok.Data;

@Data
public class Board_Dto implements Serializable {

	private static final long serialVersionUID = -8327726446798104731L;

	private String board_seq;
	private String writer;
	private String board_title;
	private String board_content;
	private String readcount;
	private String regdate;
	private String refer;
	private String step;
	private String dep;

}
