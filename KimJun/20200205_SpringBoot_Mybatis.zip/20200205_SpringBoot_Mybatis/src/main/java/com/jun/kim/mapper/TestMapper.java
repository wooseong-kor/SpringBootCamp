package com.jun.kim.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import com.jun.kim.dto.Board_Dto;

@Mapper
public interface TestMapper {
//	public String getValueFromDatabase();
//	@Select("select now()")
	public String getTime();
	
//	@Select("SELECT BOARD_SEQ, WRITER, BOARD_TITLE, READCOUNT, REGDATE FROM BOARDPRACTICE")
	public List<Board_Dto> selectAll();
	
//	@Select("SELECT BOARD_SEQ, WRITER, BOARD_TITLE, BOARD_CONTENT, REGDATE FROM BOARDPRACTICE WHERE BOARD_SEQ =#{board_seq}")
	public Board_Dto selectOne(int board_seq);
}