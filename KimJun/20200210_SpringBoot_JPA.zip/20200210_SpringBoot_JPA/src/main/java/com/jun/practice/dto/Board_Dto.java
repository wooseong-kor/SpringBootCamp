package com.jun.practice.dto;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

import lombok.Data;

@Data
@Entity
@Table(name="board_jpa")
public class Board_Dto {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private int seq;
	private String writer;
	private String title;
	private String refer;
	private String step;
	private String content;
	@CreationTimestamp
	private Date regdate;
}
