package com.jun.practice.persistence;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.CrudRepository;

import com.jun.practice.dto.Board_Dto;

public interface BoardRepository extends CrudRepository<Board_Dto, Integer>{

	public List<Board_Dto> findBoard_DtoByTitle(String title, Pageable paging);

	
	
}
