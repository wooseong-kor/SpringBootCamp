package com.jun.practice.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.jun.practice.dto.Board_Dto;
import com.jun.practice.dto.QBoard_Dto;
import com.jun.practice.persistence.BoardRepository;
import com.querydsl.core.BooleanBuilder;

@Controller
public class MainController {

	@Autowired
	private BoardRepository repo;
	
	BooleanBuilder builder = new BooleanBuilder();
	QBoard_Dto board = QBoard_Dto.board_Dto;
	
	String type = "t";
	
	
	@RequestMapping(value = "/hello", method = {RequestMethod.GET, RequestMethod.POST})
	public String Hello(Model model) {
		System.out.println("??");
		Board_Dto dto = new Board_Dto();
		for (int i = 0; i < 100; i++) {
			dto.setTitle("Test"+i);
			dto.setContent("Test"+i);
			dto.setRefer("0");
			dto.setWriter("tester");
			repo.save(dto);
		}
		return "Hello";
	}
	
	@RequestMapping(value = "/all", method = {RequestMethod.GET, RequestMethod.POST})
	public String All(Model model) {
		System.out.println("All");
		List<Board_Dto> lists =  (List<Board_Dto>) repo.findAll();
		System.out.println(lists);
		model.addAttribute("lists", lists);
		return "All";
	}
	
	@RequestMapping(value = "/paging", method = {RequestMethod.GET, RequestMethod.POST})
	public String paging(Model model, String keyword) {
		System.out.println("Paging");
		builder.and(board.title.like("%" + keyword +"%"));
		System.out.println(builder);
		Pageable paging = PageRequest.of(0, 10);
		Page<Board_Dto> pages = repo.findAll(builder, paging);
		System.out.println(pages);
		List<Board_Dto> lists = pages.getContent();
		System.out.println(lists);
		model.addAttribute("lists", lists);
		return "Paging";
	}
	
	@RequestMapping(value = "/One", method = {RequestMethod.GET, RequestMethod.POST})
	public String One(Model model, int seq) {
		System.out.println("One");
		Optional<Board_Dto> dto = repo.findById(seq);
		model.addAttribute("dto", dto.get());
		return "One";
	}
	
	@RequestMapping(value = "/title", method = {RequestMethod.GET, RequestMethod.POST})
	public String Title(Model model, String title, String page) {
		System.out.println("One");
//		System.out.println(page);
		if(page == null) {
			page = "0";
		}
		Pageable paging = PageRequest.of((Integer.parseInt(page)), 10);
		System.out.println(paging.getPageSize());
		Page<Board_Dto> pages = repo.findBoard_DtoByTitle(title, paging);
		List<Board_Dto> lists = pages.getContent();
		System.out.println(pages);
		System.out.println(pages.getTotalPages());
		System.out.println(pages.getTotalElements());
		System.out.println(pages.nextPageable());
		model.addAttribute("lists", lists);
		model.addAttribute("getnumber", pages.getNumber());
		model.addAttribute("nextnumber", pages.nextPageable());
		return "Title";
	}
	
	@RequestMapping(value = "/delete", method = {RequestMethod.GET, RequestMethod.POST})
	public String delete(int seq) {
		System.out.println("delete");
		repo.deleteById(seq);
		
		return "redirect:/all";
	}
	
	@RequestMapping(value = "/update", method = {RequestMethod.GET, RequestMethod.POST})
	public String update(Model model, int seq) {
		System.out.println("update");
		Optional<Board_Dto> dtos = repo.findById(seq);
		Board_Dto dto = dtos.get();
		dto.setTitle("update01");
		repo.save(dto);
		return "redirect:/One?seq="+seq;
	}
	
	
	
}
