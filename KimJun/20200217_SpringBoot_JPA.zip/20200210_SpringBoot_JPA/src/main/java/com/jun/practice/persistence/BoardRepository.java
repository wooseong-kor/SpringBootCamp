package com.jun.practice.persistence;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.data.repository.CrudRepository;

import com.jun.practice.dto.Board_Dto;

public interface BoardRepository extends CrudRepository<Board_Dto, Integer>, QuerydslPredicateExecutor<Board_Dto>{

	public Page<Board_Dto> findBoard_DtoByTitle(String title, Pageable paging);
	
	@Query("SELECT b FROM Board_Dto b WHERE CONTENT LIKE %:keyword%")
	public List<Board_Dto> findBoard_DtoByKeyword(String keyword);
	
	
	
}
